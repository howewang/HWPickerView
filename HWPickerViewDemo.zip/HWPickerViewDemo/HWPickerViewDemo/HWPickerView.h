//
//  HWPickerView.h
//  UIDatePickerTest01
//
//  Created by Howe on 14-8-27.
//  Copyright (c) 2014年 Howe. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^HWPickerDoneHandler)(NSDictionary *value);
typedef void(^HWPickerCancelHandler)();
typedef void(^HWPickerScrollHandler) (NSInteger component);
@protocol HWPickerViewDelegate <NSObject>

-(CGFloat)rowHightFroComponent:(NSInteger)component;

@end
@interface HWPickerView : UIView


@property (strong , nonatomic) id<HWPickerViewDelegate>delegate;
@property (assign , nonatomic) NSInteger seletedRowIndext;
//传入pickier要显示的数据---数组,block回调会在点击确定的时候返回pickerView上的value
- (void)loadDatas:(NSArray *)array doneHandler:(HWPickerDoneHandler)doneHandler cancelHandler:(HWPickerCancelHandler)cancelHandler;
//滑动pickerView调用block
- (void)scrollDoneHandler:(HWPickerScrollHandler)scrollDoneHandler;
//如果希望显示多段滚轴,实现下面方法,添加滚轴之后需要手动调用reloadData方法
- (void)addComponentWithData:(NSArray *)array;
//按照下标显示
- (void)showDataWithRow:(NSInteger)row inComponent:(NSInteger)component;


//显示pickerView
- (void)showPickerView;
//关闭plickerView
- (void)closePickerView;

//底层视图颜色
- (void)contentViewBackgroundColor:(UIColor *)color;
//pickerView视图颜色
- (void)pickerViewBackgroundColor:(UIColor *)color;
//删除所有数据
- (void)removeAllValue;
//重新加载数据
- (void)reloadData;
@end
