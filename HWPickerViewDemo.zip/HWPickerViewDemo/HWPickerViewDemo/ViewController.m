//
//  ViewController.m
//  HWPickerViewDemo
//
//  Created by Howe on 2017/6/20.
//  Copyright © 2017年 Howe. All rights reserved.
//

#import "ViewController.h"
#import "HWPickerView.h"
@interface ViewController ()
@property (strong , nonatomic) HWPickerView *picker;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.picker = [[HWPickerView alloc]init];
    [self.picker loadDatas:@[@"1",@"2",@"2"] doneHandler:^(NSDictionary *value) {
        
    } cancelHandler:^{
        
    }];
    [self.view addSubview:self.picker];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)button:(id)sender {
    [self.picker showPickerView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
