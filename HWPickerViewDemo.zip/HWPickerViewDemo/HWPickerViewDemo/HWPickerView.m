//
//  HWPickerView.m
//  UIDatePickerTest01
//
//  Created by Howe on 14-8-27.
//  Copyright (c) 2014年 Howe. All rights reserved.
//

#import "HWPickerView.h"

#define WINDOW_Width [[UIScreen mainScreen] bounds].size.width
#define WINDOW_Height [[UIScreen mainScreen] bounds].size.height

typedef void(^HWPickerDoneHandler)(NSDictionary *value);
typedef void(^HWPickerCancelHandler)();
typedef void(^HWPickerScrollHandler) (NSInteger component);

@interface HWPickerView ()<UIPickerViewDataSource,UIPickerViewDelegate>
@property (strong , nonatomic) UIView *contentView;
@property (strong , nonatomic) UIPickerView *pikcerView;
@property (strong , nonatomic) UIButton *cancelButton;
@property (strong , nonatomic) UIButton *doneButton;


//显示用的所有数据
@property (strong , nonatomic) NSMutableArray *dataArray;
@property (strong , nonatomic) NSMutableDictionary *valueDic;
@property (strong , nonatomic) HWPickerScrollHandler scrollDoneHandler;
@property (strong , nonatomic) HWPickerDoneHandler doneHandler;
@property (strong , nonatomic) HWPickerCancelHandler cancelHandler;
@end

@implementation HWPickerView

- (id)init
{
    self = [super initWithFrame:CGRectMake(0, WINDOW_Height - 250, WINDOW_Width, 250)];
    if (self) {
        // Initialization code
        //初始化视图
        self.dataArray = [[NSMutableArray arrayWithCapacity:1]mutableCopy];
        self.valueDic = [NSMutableDictionary dictionaryWithCapacity:1];
        [self initView];
        
    }
    return self;
}

-(void)initView
{
    self.contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [self addSubview:self.contentView];
    self.backgroundColor = [UIColor colorWithRed:219/255.0 green:219/255.0 blue:219/255.0 alpha:1];
    
    self.layer.shadowOffset = CGSizeMake(0, -3);
    self.layer.shadowColor = [[UIColor grayColor] CGColor];
    self.layer.shadowOpacity = 0.5;
    self.layer.shadowRadius = 2.0;
    
    self.pikcerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 35, self.frame.size.width, self.frame.size.height-35)];
    self.pikcerView.dataSource = self;
    self.pikcerView.delegate = self;
    self.pikcerView.showsSelectionIndicator = YES;
    self.pikcerView.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    [self.contentView addSubview:self.pikcerView];

    self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.cancelButton.frame = CGRectMake(5, 3, 40, 29);
    [self.cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    [self.cancelButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    self.cancelButton.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [self.cancelButton addTarget:self action:@selector(cancelButtonFunc:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.cancelButton];
    
    self.doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.doneButton.frame = CGRectMake(self.frame.size.width-45, 3, 40, 29);
    [self.doneButton setTitle:@"确定" forState:UIControlStateNormal];
    [self.doneButton setTitleColor:[UIColor colorWithRed:24/255.0 green:112/255.0 blue:209/255.0 alpha:1] forState:UIControlStateNormal];
    self.doneButton.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [self.doneButton addTarget:self action:@selector(doneButtonFunc:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.doneButton];
    
    float y = WINDOW_Height-self.frame.size.height/2;
    self.center = CGPointMake(self.frame.size.width/2, y);
    
}

-(void)scrollDoneHandler:(HWPickerScrollHandler)scrollDoneHandler
{
    self.scrollDoneHandler = scrollDoneHandler;
}
-(void)contentViewBackgroundColor:(UIColor *)color
{
    self.contentView.backgroundColor = color;
}

-(void)pickerViewBackgroundColor:(UIColor *)color
{
    self.pikcerView.backgroundColor = color;
}

-(void)cancelButtonFunc:(UIButton *)btn

{
    float y = WINDOW_Height+self.frame.size.height/2;
    [UIView animateWithDuration:0.2 animations:^{
         self.center = CGPointMake(WINDOW_Width/2, y);
    }completion:^(BOOL finished) {

    }];
     

    
}

-(void)doneButtonFunc:(UIButton *)btn
{
    if (self.valueDic.count < self.dataArray.count) {
            for (int i = 0 ; i< self.dataArray.count ; i++) {
                NSInteger row = [self.pikcerView selectedRowInComponent:i];
                NSArray *array = self.dataArray[i];
                [self.valueDic setObject:[NSString stringWithFormat:@"%@",array[row]] forKey:[NSString stringWithFormat:@"component%d",i]];
            }
    }
    if (self.doneHandler) {
        self.doneHandler(self.valueDic);
    }
    
    float y = WINDOW_Height+self.frame.size.height/2;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(WINDOW_Width/2, y);
    }completion:^(BOOL finished) {
        
        
    }];
}

-(void)showPickerView
{

    float y = WINDOW_Height+self.frame.size.height/2;
    self.center = CGPointMake(self.frame.size.width/2, y);
    
    float y2 = WINDOW_Height-self.frame.size.height/2+5;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(self.frame.size.width/2, y2);

    }];
    
}

-(void)closePickerView
{
    if (self.cancelHandler) {
        self.cancelHandler();
    }
    float y = WINDOW_Height+self.frame.size.height/2;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(self.frame.size.width/2, y);
    }completion:^(BOOL finished) {
        
        
    }];
}
-(void)loadDatas:(NSArray *)array doneHandler:(HWPickerDoneHandler)doneHandler cancelHandler:(HWPickerCancelHandler)cancelHandler
{
    [self.dataArray removeAllObjects];
    [self.dataArray addObject:array];
    [self.pikcerView reloadAllComponents];
//    self.value = [self.oneDataArray objectAtIndex:0];
    [self.pikcerView selectRow:0 inComponent:0 animated:YES];
    self.doneHandler = doneHandler;
    self.cancelHandler = cancelHandler;
}

- (void)addComponentWithData:(NSArray *)array
{
    [self.dataArray addObject:array];
}


-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return self.dataArray.count;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *array = self.dataArray[component];
    return array.count;
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSArray *array = self.dataArray[component];
    return [NSString stringWithFormat:@"%@",array[row]];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSArray *array = self.dataArray[component];
    if (array.count>0) {
        NSString *value = [NSString stringWithFormat:@"%@",array[row]];
        NSString *key = [NSString stringWithFormat:@"component%ld",component];
        [self.valueDic setObject:value forKey:key];
    }
    if (self.scrollDoneHandler) {
         self.scrollDoneHandler(component);
    }
   
}

-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    if ([self.delegate respondsToSelector:@selector(rowHightFroComponent:)]) {
        return [self.delegate rowHightFroComponent:component];
    }
    return 35;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        // Setup label properties - frame, font, colors etc
        //adjustsFontSizeToFitWidth property to YES
        pickerLabel.minimumScaleFactor = 0.0;
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:20]];
    }
    // Fill the label text here
    pickerLabel.text=[self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}


-(void)removeAllValue
{
    [self.valueDic removeAllObjects];
    [self.dataArray removeAllObjects];
    [self.pikcerView reloadAllComponents];
}

-(void)reloadData
{
    [self.pikcerView reloadAllComponents];
}

-(void)showDataWithRow:(NSInteger)row inComponent:(NSInteger)component
{
    [self.pikcerView selectRow:row inComponent:component animated:YES];
    [self pickerView:self.pikcerView didSelectRow:row inComponent:component];
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
